from django.shortcuts import render
from .models import Item

# Create your views here.
